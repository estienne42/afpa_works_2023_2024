// 1   FONCTIONS_UTILISEES
// 2   VARIABLES
// 3     h EST_DU_TYPE NOMBRE
// 4     m EST_DU_TYPE NOMBRE
// 5     s EST_DU_TYPE NOMBRE
// 6   DEBUT_ALGORITHME
// 7     AFFICHER "Entrer les heures : "
// 8     LIRE h
// 9     AFFICHER "Entrer les minutes : "
// 10    LIRE m
// 11    AFFICHER "Entrer les secondes : "
// 12    LIRE s
// 13    s PREND_LA_VALEUR s+1
// 14    SI (s==60) ALORS
// 15      DEBUT_SI
// 16      s PREND_LA_VALEUR 0
// 17      m PREND_LA_VALEUR m+1
// 18      SI (m==60) ALORS
// 19        DEBUT_SI
// 20        m PREND_LA_VALEUR 0
// 21        h PREND_LA_VALEUR h+1
// 22        SI (h==24) ALORS
// 23          DEBUT_SI
// 24          h PREND_LA_VALEUR 0
// 25          FIN_SI
// 26        FIN_SI
// 27      FIN_SI
// 28    AFFICHER "Dans un seconde, il sera "
// 29    AFFICHER h
// 30    AFFICHER ":"
// 31    AFFICHER m
// 32    AFFICHER ":"
// 33    AFFICHER s
// 34    AFFICHER "."
// 35  FIN_ALGORITHME
